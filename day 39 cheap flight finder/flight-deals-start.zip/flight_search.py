class FlightSearch:
    #This class is responsible for talking to the Flight Search API.
    pass