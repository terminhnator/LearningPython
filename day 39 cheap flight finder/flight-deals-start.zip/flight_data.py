class FlightData:
    #This class is responsible for structuring the flight data.
    pass